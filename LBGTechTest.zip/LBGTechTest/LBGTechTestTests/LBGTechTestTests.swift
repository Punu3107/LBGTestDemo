//
//  LBGTechTestTests.swift
//  LBGTechTestTests
//
//  Created by Puneet on 28/02/25.
//

import XCTest
@testable import LBGTechTest

final class LBGTechTestTests: XCTestCase {
    var apiClient: MockAPIClient!
    var sut: LBGViewModel!
    
    override func setUp() {
        // Put setup code here.
        super.setUp()
       
        apiClient = MockAPIClient()
        let appConfiguration = AppConfiguration()
        let apiConfiguration = APIConfiguration(configuration: appConfiguration)
        let remoteDataSource = FetchServerData(apiClient: apiClient, apiConfiguration: apiConfiguration)
        let dogsDataRepository = DogsDataRepositoryClass(dataSource: remoteDataSource)
        let fetchUserCase = FetchDataUseCase(repository: dogsDataRepository)
        sut = LBGViewModel(fetchDataUseCase: fetchUserCase)
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        apiClient = nil
        
        sut = nil
        super.tearDown()
    }
    
    func test_fetchDogsFact_Data_Success() {
        let storyBoard = UIStoryboard(name: "Main", bundle: Bundle.main)
        guard let controller = storyBoard.instantiateViewController(withIdentifier: "LBGViewContoller") as? LBGViewContoller else {
            XCTFail()
            return
        }
        sut.fetchDogsData(viewController: controller)
        DispatchQueue.main.asyncAfter(deadline: .now()+3) {
            XCTAssertNotNil(self.sut.dogFacts)
        }
    }
    
    func test_fetchDogsFact_Data_Failure() {
        let storyBoard = UIStoryboard(name: "Main", bundle: Bundle.main)
        guard let controller = storyBoard.instantiateViewController(withIdentifier: "LBGViewContoller") as? LBGViewContoller else {
            XCTFail()
            return
        }
        sut.fetchDogsData(viewController: controller)
        XCTAssertNil(sut.dogFacts)
    }
    
}
