//
//  DogsDataRepositoryTests.swift
//  LBGTechTestTests
//
//  Created by Puneet on 05/03/25.
//

import XCTest
@testable import LBGTechTest

class UserRepositoryTests: XCTestCase {
    var apiClient: MockAPIClient!
    var dogsDataRepository: DogsDataRepositoryClass!

    override func setUp() {
        super.setUp()
        apiClient = MockAPIClient()
        let appConfiguration = AppConfiguration()
        let apiConfiguration = APIConfiguration(configuration: appConfiguration)
        let remoteDataSource = FetchServerData(apiClient: apiClient, apiConfiguration: apiConfiguration)
        dogsDataRepository = DogsDataRepositoryClass(dataSource: remoteDataSource)
    }

    override func tearDown() {
        apiClient = nil
        dogsDataRepository = nil
        super.tearDown()
    }

    func testFetchDataSuccess() {
        let expectation = XCTestExpectation(description: "Fetch Data successfully")

        dogsDataRepository.fetchFactData() { result in
            switch result {
            case .success(let data):
                XCTAssertEqual(data.facts.count, 1)
                expectation.fulfill()
            case .failure:
                XCTFail("Expected success but got failure")
            }
        }

        wait(for: [expectation], timeout: 5.0)
    }
    
    func testFetchUserFailure() {
        apiClient.shouldReturnError = true
        let expectation = XCTestExpectation(description: "Fetch Data with error")

        dogsDataRepository.fetchFactData() { result in
            switch result {
            case .success:
                XCTFail("Expected failure but got success")
            case .failure(let error):
                XCTAssertEqual(error.localizedDescription, "Test Error")
                expectation.fulfill()
            }
        }

        wait(for: [expectation], timeout: 5.0)
    }
}

// Mock Manager Class
class MockAPIClient: LBGNetworkManager {
    var shouldReturnError = false

    override func requestData<T>(urlRequest:URLRequest, completion: @escaping (Result<T, Error>) -> Void) where T : Decodable {
        if shouldReturnError {
            completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Test Error"])))
        } else {
            let data = DogFactsData(facts: ["Bingo is the name of the dog on the side of the Cracker Jack box."], success: true)
            completion(.success(data as! T))
        }
    }

}


