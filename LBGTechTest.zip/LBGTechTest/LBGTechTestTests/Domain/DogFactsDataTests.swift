//
//  DogFactsDataTests.swift
//  LBGTechTestTests
//
//  Created by Puneet on 05/03/25.
//

import XCTest
@testable import LBGTechTest

// Test case for DogFactsData Codable functionality
class DogFactsDataTests: XCTestCase {
    
    // Test decoding of a valid JSON string to UsersModelDTO
    func test_decodeDogFactsDataDTO_withSuceesForValidJson() {
        // Given
        let jsonString = """
         {"facts":
        ["Bingo is the name of the dog on the side of the Cracker Jack box."
        ],
        "success":false
        }
        """
        let jsonData = jsonString.data(using: .utf8)!
        
        // When
        let decoder = JSONDecoder()
        do {
            let dogsData = try decoder.decode(DogFactsData.self, from: jsonData)
            
            // Then
            XCTAssertEqual(dogsData.facts?.count, 1)
            XCTAssertEqual(dogsData.success, false)
        } catch {
            XCTFail("Decoding failed: \(error)")
        }
    }
    
    // Test decoding when some fields are missing
    func test_decodeUsersModelDTO_withSuceesForMissingfields() {
        // Given
        let jsonString = """
            {"facts":
            ["Bingo is the name of the dog on the side of the Cracker Jack box."
            ]
            }
            """
        let jsonData = jsonString.data(using: .utf8)!
        
        // When
        let decoder = JSONDecoder()
        do {
            let dogsData = try decoder.decode(DogFactsData.self, from: jsonData)
            // Then
            XCTAssertEqual(dogsData.facts?.count, 1)
            XCTAssertNil(dogsData.success)
        } catch {
            XCTFail("Decoding failed: \(error)")
        }
    }
    
    // Test decoding invalid JSON should throw an error
    func test_decodeUsersModelDTO_FailureWithInvalidJson() {
        // Given
        let jsonString = """
                    {"facts":
                    ["Bingo is the name of the dog on the side of the Cracker Jack box."
                    ],
                                ,
                                 "success":"true"
                    }
                    """
        let jsonData = jsonString.data(using: .utf8)!
        
        // When
        let decoder = JSONDecoder()
        XCTAssertThrowsError(try decoder.decode(DogFactsData.self, from: jsonData), "Expected decoding error for invalid id type") { error in
            print("Decoding failed as expected with error: \(error)")
        }
    }
}
