//
//  FetchDataUseCaseTests.swift
//  LBGTechTestTests
//
//  Created by Puneet on 05/03/25.
//

import XCTest
@testable import LBGTechTest

class FetchUserUseCaseTests: XCTestCase {
    var dogsDataRepository: MockDogsDataRepository!
    var sut: FetchDataUseCase!
    
    override func setUp() {
        super.setUp()
        dogsDataRepository = MockDogsDataRepository()
        sut = FetchDataUseCase(repository: dogsDataRepository)
    }
    
    override func tearDown() {
        dogsDataRepository = nil
        sut = nil
        super.tearDown()
    }
    //Test For Execute Success
    func testExecuteSuccess() {
        let expectation = XCTestExpectation(description: "Fetch Data successfully")
        
        sut.executeData { result in
            switch result {
            case .success(let data):
                XCTAssertEqual(data.facts.count, 1)
                expectation.fulfill()
            case .failure:
                XCTFail("Expected success but got failure")
            }
        }
        
        wait(for: [expectation], timeout: 5.0)
    }
    //Test for Execute Failure
    func testExecuteFailure() {
        dogsDataRepository.shouldReturnError = true
        let expectation = XCTestExpectation(description: "Fetch data with error")
        
        sut.executeData() { result in
            switch result {
            case .success:
                XCTFail("Expected failure but got success")
            case .failure(let error):
                XCTAssertEqual(error.localizedDescription, "Test Error")
                expectation.fulfill()
            }
        }
        wait(for: [expectation], timeout: 5.0)
    }
}

// Mock users Repository
class MockDogsDataRepository: DogsDataRepository {
    var shouldReturnError = false

    func fetchFactData( completion: @escaping (Result<DogFacts, Error>) -> Void) {
        if shouldReturnError {
            completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Test Error"])))
        } else {
            let data = DogFactsData(facts: ["Bingo is the name of the dog on the side of the Cracker Jack box."], success: true)
            completion(.success(DogFacts(facts: data.facts ?? [], success: data.success ?? false)))
        }
    }
}

