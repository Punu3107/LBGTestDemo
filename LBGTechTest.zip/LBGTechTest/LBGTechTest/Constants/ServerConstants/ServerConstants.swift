//
//  ServerConstants.swift
//
//  Created by Puneet on 28/02/25.
//

struct HOST {
    static let DOGFactURL =  "dog-api.kinduff.com"
}

struct Path {
    static let dogfacts = "/api/facts"
}

enum HttpMethod: String {
    case get = "GET"
    case post = "POST"
}

struct AppNetworkConstant{
    static let localdataloadingfailed = "Failed to load local data"
    static let invalidUrl = "Invalid URL"
    static let localJsonFileloadingfailed = "Error loading local JSON file:"
    
}

