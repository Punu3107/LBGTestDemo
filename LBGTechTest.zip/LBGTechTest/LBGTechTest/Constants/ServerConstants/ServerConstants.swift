//
//  ServerConstants.swift
//
//  Created by Puneet on 28/02/25.
//

struct HOST {
    static let DOGFactURL =  "dog-api.kinduff.com"
}

struct Path {
    static let dogfacts = "/api/facts"
}

enum HttpMethod: String {
    case get = "GET"
    case post = "POST"
}


