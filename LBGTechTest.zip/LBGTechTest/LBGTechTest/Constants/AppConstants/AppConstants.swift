//
//  AppConstants.swift
//  LBGTechTest
//
//  Created by Puneet on 28/02/25.
//

struct StoryboardId{
    static let vcLloydBanking = "LBGViewContoller"
}

struct StoryboardName {
    static let Main = "Main"
}

struct CellIdentifier {
    static let lloydBankingCell = "LloydBankingCell"
}
