//
//  Router.swift
//  LBGTechTest
//
//  Created by Puneet on 28/02/25.
//

import Foundation

enum LBGRouter {
    case dogFactAPI
    
    // Host URLs
    var host: String {
        switch self {
        case .dogFactAPI:
            return HOST.DOGFactURL
        }
    }
    
    // Schemes For  Request
    var scheme: String {
        switch self {
        case .dogFactAPI:
            return "https"
        }
    }
    
    // API Path For  Request
    var path: String {
        switch self {
        case .dogFactAPI:
            return Path.dogfacts
        }
    }
    
    //Http Methods
    var method: String {
        switch self {
        case .dogFactAPI:
            return HttpMethod.get.rawValue
        }
    }
    
    //Query Items
    var query: [URLQueryItem] {
        switch self {
        case .dogFactAPI:
            return [URLQueryItem(name: "number", value: "10")]
        }
    }
}

