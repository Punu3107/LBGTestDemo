//
//  ConfigurationManager.swift
//  LBGTechTest
//
//  Created by Puneet on 04/03/25.
//

import Foundation

final class AppConfiguration: ConfigurationProtocol {
    
    
    var apiKey: String {
        return ""
    }
    
    // Host URLs
    var host: String {
        return HOST.DOGFactURL
    }
    
    // Schemes For  Request
    var scheme: String {
        return "https"
    }
    
    
    // API Path For  Request
    var path: String {
        return Path.dogfacts
    }
    
    
    //Http Methods
    var method: String {
        return HttpMethod.get.rawValue
    }
    
    //Query Items
    var query: [URLQueryItem] {
        return [URLQueryItem(name: "number", value: "10")]
    }
}
