//
//  ErrorHandler.swift
//  LBGTechTest
//
// //  Created by Puneet on 28/02/25.

// Here we have define custom error types

enum NetworkError: Error {
    case badRequest
    case unauthorized
    case forbidden
    case notFound
    case serverError
    case unknown
    case customError(String)
}

class LBGErrorHandler {
    static func handleError(error: Error) {
        if let networkError = error as? NetworkError {
            switch networkError {
            case .badRequest:
                debugPrint("Bad request - The server could not understand the request due to invalid syntax.")
            case .unauthorized:
                debugPrint("Unauthorized - Please check your credentials.")
            case .forbidden:
                debugPrint("Forbidden - You do not have permission to access this resource.")
            case .notFound:
                debugPrint("Not Found - The requested resource could not be found.")
            case .serverError:
                debugPrint("Server Error - There was an issue on the server's end.")
            case .customError(let message):
                debugPrint("Error: \(message)")
            case .unknown:
                debugPrint("An unknown error occurred.")
            }
        } else {
            // Handle other types of errors (e.g., decoding issues)
            debugPrint("An unexpected error occurred: \(error.localizedDescription)")
        }
    }
}

