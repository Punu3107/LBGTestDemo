//
//  LBJsonDecoder.swift
//  LBGTechTest
//
//  Created by Puneet on 28/02/25.
//

import Foundation

//Json Decorder
class LBGJsonDecoder {
    static func decode<T: Codable>(data: Data) throws -> T {
        let decoder = JSONDecoder()
        let decodedObject = try decoder.decode(T.self, from: data)
        print(decodedObject)
        return decodedObject
    }
}
