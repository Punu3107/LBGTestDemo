//
//  APIConfiguration.swift
//  LBGTechTest
//
//  Created by Puneet on 04/03/25.
//

import Foundation

public class APIConfiguration {
    private let configuration: ConfigurationProtocol
    
    init(configuration: ConfigurationProtocol) {
        self.configuration = configuration
    }
    
    func makeUserURL() -> URL? {
        let baseURL = configuration.host
        let scheme = configuration.scheme
        let queryItem = configuration.query
        let path = configuration.path
        
        var components = URLComponents()
        components.host = baseURL
        components.path = path
        components.scheme = scheme
        components.queryItems = queryItem
        return components.url
    }
}
