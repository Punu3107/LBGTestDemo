//
//  RemoteData.swift
//  LBGTechTest
//
//  Created by Puneet on 04/03/25.
//

import Foundation

public class FetchServerData:DogsFactDataSource {
    
    private let apiClient: ClientAPIProtocol
    private let apiConfiguration:APIConfiguration
    
    init(apiClient: ClientAPIProtocol, apiConfiguration:APIConfiguration) {
        self.apiClient = apiClient
        self.apiConfiguration = apiConfiguration
    }
    
    func fetchDogsData(completion: @escaping (Result<DogFactsData, Error>) -> Void) {
        guard let url = apiConfiguration.makeUserURL() else {
            completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: AppNetworkConstant.invalidUrl])))
            return
        }
        
         var request = URLRequest(url: url)
        request.httpMethod = HttpMethod.get.rawValue
        apiClient.requestData(urlRequest: request, completion: completion)
    }
}

