//
//  ClientAPIProtocol.swift
//  LBGTechTest
//
//  Created by Puneet on 04/03/25.
//

import Foundation
public protocol ClientAPIProtocol {
    func requestData<T: Decodable>(urlRequest:URLRequest, completion: @escaping (Result<T, Error>) -> Void)
}
