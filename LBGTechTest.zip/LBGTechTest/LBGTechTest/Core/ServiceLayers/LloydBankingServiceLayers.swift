//
//  LloydBankingServiceLayers.swift
//  LBGTechTest
//
//  Created by Puneet on 28/02/25.
//

class LBGServiceLayers {
    static func request<T: Codable>(router: LBGRouter) async throws -> T {
        let request = try URLRequests.request(from: router)
        let data = try await LBGNetworkManager.requestData(for: request)
        let responseObject: T = try LBGJsonDecoder.decode(data: data)
        return responseObject
    }
}
