//
//  DogsDataRepositoryClass.swift
//  LBGTechTest
//
//  Created by Puneet on 04/03/25.
//

import Foundation

final class DogsDataRepositoryClass: DogsDataRepository {
    private let dataSource: DogsFactDataSource
    
    init(dataSource: DogsFactDataSource) {
        self.dataSource = dataSource
    }
    
    func fetchFactData(completion: @escaping (Result<DogFacts, Error>) -> Void) {
        
        dataSource.fetchDogsData { result in
            switch result {
            case .success(let data):
                completion(.success(DogFacts(facts: data.facts ?? [], success: data.success ?? false)))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}
