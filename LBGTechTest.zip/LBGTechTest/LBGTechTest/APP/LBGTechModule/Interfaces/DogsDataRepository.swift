//
//  DogsDataRepository.swift
//  LBGTechTest
//
//  Created by Puneet on 04/03/25.
//

import Foundation

protocol DogsDataRepository {
    func fetchFactData(completion: @escaping (Result<DogFacts, Error>) -> Void)
}
