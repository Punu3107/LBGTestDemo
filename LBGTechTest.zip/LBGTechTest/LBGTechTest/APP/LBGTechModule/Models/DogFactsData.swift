//
//  DogFactsData.swift
//  LBGTechTest
//
//  Created by Puneet on 04/03/25.
//

// MARK: - DogFactsData element
class DogFactsData: Codable {
    var facts: [String]?
    var success: Bool?

    init(facts:[String]?, success: Bool?) {
        self.facts = facts
        self.success = success
    }
}
