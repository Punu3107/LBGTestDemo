//
//  LBGViewContoller+Extensions.swift
//  LBGTechTest
//
//  Created by Puneet on 28/02/25.
//

import UIKit
// MARK: - TableView DataSource
extension LBGViewContoller: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.lbgViewModel?.dogFacts?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        if let fact = lbgViewModel?.dogFacts?[indexPath.row] {
            cell.textLabel?.text = fact
            cell.textLabel?.numberOfLines = 0
        } else {
            cell.textLabel?.text = "NA"
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}


//MARK: - Extension for Protocols
extension LBGViewContoller: ViewControllerProtocols {
    
    func fetchDogFactsData() {
        lbgViewModel?.fetchDogsData(viewController: self)
    }
    
    // Load UI Data
    func loadUIData() {
        self.reloadTable()
    }
    // Setup UI Elements
    func setupUIData() {
        //set Navigation Title
        self.title = "Dog Facts"
        // setup TableView delegate
        tableViewFacts.dataSource = self
        tableViewFacts.delegate = self
        tableViewFacts.rowHeight = UITableView.automaticDimension
        // lbgViewModel Object
        lbgViewModel = LBGViewModel()
        lbgViewModel?.delegate = self
    }
}

//MARK: - LBGUpdateViewProtocol
extension LBGViewContoller: LBGUpdateViewProtocol {
    func updateCotroller() {
        self.loadUIData()
    }
}


