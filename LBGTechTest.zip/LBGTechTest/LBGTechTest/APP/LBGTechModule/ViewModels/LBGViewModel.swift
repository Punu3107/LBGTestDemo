//
//  LBGViewModel.swift
//  LBGTechTest
//
//  Created by Puneet on 28/02/25.
//

import Foundation
import UIKit



protocol LBGUpdateViewProtocol: AnyObject {
    func updateCotroller()
}


final class LBGViewModel {
    var dogFacts: [String]?
    private let fetchDataUseCase: FetchDataUseCase
    var errorMessage: String?
    weak var delegate : LBGUpdateViewProtocol?
    
    //MARK: - Fetch Dog Data
    public init(fetchDataUseCase: FetchDataUseCase) {
        self.fetchDataUseCase = fetchDataUseCase
    }
    
    public func fetchDogsData(viewController: UIViewController) {
        fetchDataUseCase.executeData() { [weak self] result in
            guard let strongSelf = self else { return }
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    strongSelf.dogFacts = data.facts
                    Hud.shared.stopLoading()
                    strongSelf.delegate?.updateCotroller()
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    strongSelf.errorMessage = error.localizedDescription
                }
            }
        }
    }
}
