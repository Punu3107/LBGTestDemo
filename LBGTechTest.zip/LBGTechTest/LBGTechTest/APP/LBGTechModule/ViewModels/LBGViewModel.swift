//
//  LBGViewModel.swift
//  LBGTechTest
//
//  Created by Puneet on 28/02/25.
//

import Foundation
import UIKit

protocol LBGFetchDogDataProtocol {
    func fetchDogsData(completion: @escaping (DogFacts?, Error?) -> Void)
}

protocol LBGUpdateViewProtocol: AnyObject {
    func updateCotroller()
}


final class LBGViewModel:LBGFetchDogDataProtocol {
    var dogFacts: [String]?
    weak var delegate : LBGUpdateViewProtocol?
    
    init(){
        
    }
    
    func fetchDogsData(viewController: UIViewController) {
        Hud.shared.startLoading(view: viewController.view)
        self.fetchDogsData(completion: { [weak self] dogFactsData, error in
            guard let strongSelf = self else { return }
            if let dogFacts = dogFactsData  {
                strongSelf.dogFacts = dogFacts.facts
                DispatchQueue.main.async {
                    Hud.shared.stopLoading()
                    strongSelf.delegate?.updateCotroller()
                }
            }
        })
    }
    
    //MARK: - Fetch Dog Data
    func fetchDogsData(completion: @escaping (DogFacts?, Error?) -> Void) {
        Task {
            do {
                if let dogFacts: DogFacts = try await LBGServiceLayers.request(router: .dogFactAPI) {
                    completion(dogFacts, nil)
                }
            } catch {
                completion(nil, error)
                LBGErrorHandler.handleError(error: error)
            }
        }
    }
}
