//
//  ControllerProtocol.swift
//  LBGTechTest
//
//  Created by Puneet on 28/02/25.
//

import Foundation

protocol LoadUIProtocol {
    func loadUIData()
    func setupUIData()
}

protocol FetchDataProtocol{
    func fetchDogFactsData()
}

protocol ViewControllerProtocols : LoadUIProtocol, FetchDataProtocol {
}



