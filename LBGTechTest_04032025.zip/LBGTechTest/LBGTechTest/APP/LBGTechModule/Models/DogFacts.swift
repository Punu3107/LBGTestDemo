//
//  DogFacts.swift
//  LBGTechTest
//
//  Created by Puneet on 28/02/25.
//

import Foundation

// MARK: - DogFacts
struct DogFacts: Codable {
    let facts: [String]
    let success: Bool
}

