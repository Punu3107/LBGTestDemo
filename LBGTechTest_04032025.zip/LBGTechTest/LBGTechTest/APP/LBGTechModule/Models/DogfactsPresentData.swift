//
//  DogfactsPresentData.swift
//  LBGTechTest
//
//  Created by Puneet on 04/03/25.
//

import Foundation
// MARK: - DogfactsPresentData
struct DogfactsPresentData: Codable {
    let facts: [String]
    let success: Bool
}
