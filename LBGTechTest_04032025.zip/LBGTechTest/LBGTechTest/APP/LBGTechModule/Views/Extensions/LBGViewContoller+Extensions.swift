//
//  LBGViewContoller+Extensions.swift
//  LBGTechTest
//
//  Created by Puneet on 28/02/25.
//

import UIKit
// MARK: - TableView DataSource
extension LBGViewContoller: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.lbgViewModel?.dogFacts?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "Cell")
        if let fact = lbgViewModel?.dogFacts?[indexPath.row] {
            cell.textLabel?.text = fact
            cell.textLabel?.numberOfLines = 0
        } else {
            cell.textLabel?.text = "NA"
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}


//MARK: - Extension for Protocols
extension LBGViewContoller: ViewControllerProtocols {
    
    func fetchDogFactsData() {
        lbgViewModel?.fetchDogsData(viewController: self)
    }
    
    // Load UI Data
    func loadUIData() {
        self.reloadTable()
    }
    // Setup UI Elements
    func setupUIData() {
        //set Navigation Title
        self.title = "Dog Facts"
        // setup TableView delegate
        tableViewFacts.dataSource = self
        tableViewFacts.delegate = self
        tableViewFacts.rowHeight = UITableView.automaticDimension
        // lbgViewModel Object
        lbgViewModel = getUserViewModel()
        lbgViewModel?.delegate = self
    }
    
    func getUserViewModel() -> LBGViewModel {
        let apiClient = LBGNetworkManager()
        let appConfiguration = AppConfiguration()
        let apiConfiguration = APIConfiguration(configuration: appConfiguration)
        let remoteDataSource = FetchServerData(apiClient: apiClient, apiConfiguration: apiConfiguration)

        let repository = DogsDataRepositoryClass(dataSource: remoteDataSource)
        let fetchDataUseCase = FetchDataUseCase(repository: repository)
        let viewModel = LBGViewModel(fetchDataUseCase: fetchDataUseCase)
        return viewModel
    }
}

//MARK: - LBGUpdateViewProtocol
extension LBGViewContoller: LBGUpdateViewProtocol {
    func updateCotroller() {
        self.loadUIData()
    }
}


