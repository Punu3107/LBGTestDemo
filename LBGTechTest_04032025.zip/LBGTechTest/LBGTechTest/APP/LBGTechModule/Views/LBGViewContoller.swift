//
//  LBGViewContoller.swift
//  LBGTechTest
//
//  Created by Puneet on 28/02/25.
//

import UIKit

class LBGViewContoller: UIViewController {
    
    var lbgViewModel:LBGViewModel?
    @IBOutlet weak var tableViewFacts: UITableView!
    
    //MARK: - Reload Table
    func reloadTable() {
        DispatchQueue.main.async {
            self.tableViewFacts.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        // set UI Elements
        setupUIData()
        // Fetching Dog fact Data from API
        fetchDogFactsData()
    }
}

