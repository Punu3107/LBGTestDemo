//
//  FetchdataUseCase.swift
//  LBGTechTest
//
//  Created by Puneet on 04/03/25.
//

import Foundation

final public class FetchDataUseCase {
    private let repository: DogsDataRepository
    
     init(repository: DogsDataRepository) {
        self.repository = repository
    }
    
    func executeData( completion: @escaping (Result<DogFacts, Error>) -> Void) {
        repository.fetchFactData( completion: completion)
    }
}
