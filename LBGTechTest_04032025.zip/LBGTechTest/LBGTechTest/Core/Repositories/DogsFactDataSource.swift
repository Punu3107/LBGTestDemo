//
//  DogFactDataSource.swift
//  LBGTechTest
//
//  Created by Puneet on 04/03/25.
//

import Foundation

protocol DogsFactDataSource {
    func fetchDogsData(completion: @escaping (Result<DogFactsData, Error>) -> Void)
}
