//
//  ConfigurationProtocol.swift
//  LBGTechTest
//
//  Created by Puneet on 04/03/25.
//

import Foundation
import Foundation

public protocol ConfigurationProtocol {
    var host: String { get }
    var scheme: String { get }
    var path: String { get }
    var method: String { get }
    var query: [URLQueryItem] { get }
    var apiKey: String { get }
}
