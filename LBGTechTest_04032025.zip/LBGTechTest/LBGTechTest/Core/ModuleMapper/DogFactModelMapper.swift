//
//  DogFactModelMapper.swift
//  LBGTechTest
//
//  Created by Puneet on 04/03/25.
//

import Foundation
struct DogFactModelMapper{
    static func toDomainData(dogFactData:DogFactsData) -> DogFacts {
        return DogFacts(facts: dogFactData.facts ?? [] , success: dogFactData.success ?? false)
    }
}
