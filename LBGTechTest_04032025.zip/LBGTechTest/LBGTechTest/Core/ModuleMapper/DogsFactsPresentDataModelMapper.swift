//
//  DogsFactsPresentDataModelMapper.swift
//  LBGTechTest
//
//  Created by Nitin on 04/03/25.
//

import Foundation
struct DogsFactsPresentDataModelMapper{
    static func toPresentation(dogFacts:DogFacts) -> DogfactsPresentData {
        return DogfactsPresentData(facts: dogFacts.facts, success: dogFacts.success)
    }
}
