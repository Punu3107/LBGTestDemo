//
//  LBGTechTestTests.swift
//  LBGTechTestTests
//
//  Created by Puneet on 28/02/25.
//

import XCTest
@testable import LBGTechTest

final class LBGTechTestTests: XCTestCase {
    var sut: LBGViewModel!

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        super.setUp()
        sut = LBGViewModel()
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        sut = nil
        super.tearDown()
    }
    
    func test_fetchDogsFact_Data() {
        let expectation = self.expectation(description: "Fetch dog facts data")
        sut.fetchDogsData { dogFactsData, error in
            if let facts = dogFactsData {
                XCTAssertNotNil(facts, "dogs fact Data not nil")
            } else {
                XCTFail("dogs fact fail to load")
            }
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 10.0)
    }

}
